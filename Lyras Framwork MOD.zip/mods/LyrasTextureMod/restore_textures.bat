@echo off
setlocal
cd /d "%~dp0"
title Lyra's Texture Mod - Restore Original Textures

:menu
cls
echo ======================================================================
echo           LYRA'S TEXTURE MOD - ORIGINAL TEXTURE RESTORE TOOL
echo ======================================================================
echo.
echo   [1] List all currently modified textures
echo   [2] Restore ALL textures to original vanilla (Automatic backup created)
echo   [3] Restore a specific texture by name or keyword
echo   [4] Flush compiled texture cache (.cache)
echo   [5] Exit
echo.
echo ======================================================================
set /p CHOICE="Enter choice [1-5]: "

if "%CHOICE%"=="1" (
    cls
    python restore_original_textures.py --list
    echo.
    pause
    goto menu
)
if "%CHOICE%"=="2" (
    cls
    echo [RESTORE] Restoring all textures to original vanilla...
    python restore_original_textures.py --all
    echo.
    pause
    goto menu
)
if "%CHOICE%"=="3" (
    cls
    set /p SEARCH="Enter texture name, GBIX or keyword (e.g. texDC0, 0054, cab): "
    python restore_original_textures.py "%SEARCH%"
    echo.
    pause
    goto menu
)
if "%CHOICE%"=="4" (
    cls
    echo Flushing compiled cache in Toolbox and Steam...
    if exist ".\cache" (
        del /Q ".\cache\*.cache" 2>nul
        echo Cleared Toolbox cache.
    )
    if exist "C:\Program Files (x86)\Steam\steamapps\common\Crazy Taxi\mods\LyrasTextureMod\cache" (
        del /Q "C:\Program Files (x86)\Steam\steamapps\common\Crazy Taxi\mods\LyrasTextureMod\cache\*.cache" 2>nul
        echo Cleared Steam cache.
    )
    echo [DONE] Cache flushed.
    pause
    goto menu
)
if "%CHOICE%"=="5" exit /b 0

goto menu
